let persons = [
  {
    name: "Atman",
    age: 20,
    city: "Delhi",
    salary: "6.3 lpa"
  },
  {
   name: "Bhairav",
    age: 25,
    city: "Chennai",
    salary: "4 lpa"
  },
  {
   name: "Chintan",
    age: 34,
    city: "Ahmedabad",
    salary: "10 lpa" 
 },
];

function display(superarray) {
  let tabledata = "";

  superarray.forEach(function (person, index) {
    let currentrow = `<tr>
    <td>${index + 1}</td>
    <td>${person.name}</td>
    <td>${person.age}</td>
    <td>${person.city}</td>
    <td>${person.salary}</td>
    <td>
    <button onclick='deleteperson(${index})'>delete</button>
    
    </td>
    </tr>`;

    tabledata += currentrow;
  });

  document.getElementsByClassName("tdata")[0].innerHTML = tabledata;
  //   document.getElementById("tdata").innerHTML = tabledata;
}

display(persons);


function searchByName() {
  let searchValue = document.getElementById("searchName").value;

  let newdata = persons.filter(function (person) {
    return (
      person.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
    );
  });

  display(newdata);
}

function searchByCity() {
  let searchValue = document.getElementById("searchCity").value;

  let newdata = persons.filter(function (person) {
    return (
      person.city.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
    );
  });

  display(newdata);
}


function deleteperson(index) {
  persons.splice(index, 1);
  display(persons);
}

let updateIndex;

