let ibuses;

window.onload = function () {

ibuses=[
{
	name: "1Danno",
	source: "Palgar",
	destination: "mumbai",
	number: 123,
	capacity: 54
},
{
	name:"Basanti",
	source:"Mumbai",
	destination:"Palgar",
	number:345,
	capacity:12
}
];


  if (localStorage.getItem("buses") == null) {
    localStorage.setItem("buses", JSON.stringify(ibuses)); 
  }

if (localStorage.getItem("buses")) { ibuses=JSON.parse(localStorage.getItem("buses")); }
 

};



function display(superarray) {
  let tabledata = "";
if (superarray==undefined) superarray=JSON.parse(localStorage.getItem("buses"));
  
  superarray.forEach(function (bus, index) {
    let currentrow = `<tr>
	<td>${bus.name}</td>
    <td>${bus.source}</td>
    <td>${bus.destination}</td>
    <td>${bus.number}</td>
    <td>${bus.capacity}</td>
    <td>
    <button onclick='deletebus(${index})'>delete</button>
    
    </td>
    </tr>`;

    tabledata += currentrow;
  });

  document.getElementsByClassName("tdata")[0].innerHTML = tabledata;
  //   document.getElementById("tdata").innerHTML = tabledata;
}

display(ibuses);


function searchBysource() {
  let searchValue = document.getElementById("searchsource").value;

  let newdata = ibuses.filter(function (bus) {
    return (
      bus.source.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
    );
  });

  display(newdata);
}

function searchBydestination() {
  let searchValue = document.getElementById("searchdestination").value;

  let newdata = ibuses.filter(function (bus) {
    return (
      bus.destination.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
    );
  });

  display(newdata);
}


function deletebus(index) {
  ibuses.splice(index, 1);
localStorage.setItem("buses",JSON.stringify(ibuses));
  display(ibuses);
}

function addbus(event) {
event.preventDefault();
let newbus={};

newbus.name=document.getElementById('bname').value;
newbus.source=document.getElementById('bsource').value;
newbus.destination=document.getElementById('bdestination').value;
newbus.number=Number(document.getElementById('bnumber').value);
newbus.capacity=Number(document.getElementById('bcapacity').value);

ibuses.push(newbus);
localStorage.setItem("buses",JSON.stringify(ibuses));
display(ibuses);	
}
